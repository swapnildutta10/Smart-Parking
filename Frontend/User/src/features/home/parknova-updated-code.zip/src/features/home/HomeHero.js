import React from "react";

const SERVICES = [
  "Reserve ahead",
  "Hourly & daily rates",
  "Monthly passes",
  "EV charging bays",
  "Covered parking",
  "Live availability",
  "Instant confirmation",
  "24/7 support",
];

const HIGHLIGHTS = [
  "Real-time availability, updated every minute",
  "Reserve a space in under sixty seconds",
  "Free cancellation, right up to arrival",
];

const STATS = [
  { icon: "⌖", value: "12,480+", label: "Drivers onboard" },
  { icon: "◉", value: "18", label: "Live locations" },
  { icon: "▤", value: "864", label: "Parking slots" },
  { icon: "✓", value: "92%", label: "Avg. availability" },
];

function HomeHero({
  authRole,
  darkMode,
  themeAnimating,
  onToggleTheme,
  onThemeAnimationEnd,
  onLoginClick,
}) {
  const [highlightIndex, setHighlightIndex] = React.useState(0);

  function showPrevHighlight() {
    setHighlightIndex((current) => (current - 1 + HIGHLIGHTS.length) % HIGHLIGHTS.length);
  }
  function showNextHighlight() {
    setHighlightIndex((current) => (current + 1) % HIGHLIGHTS.length);
  }

  return (
    <div className="pn-fh-page">
      <nav className="pn-fh-nav" aria-label="Primary">
        <a className="pn-fh-brand" href="#top">
          <span>P</span> ParkNova
        </a>
        <div className="pn-fh-links">
          <a href="#home">Home</a>
          <a href="#features">Features</a>
          <a href="#pricing">Pricing</a>
          <a href="#parking">Find a spot</a>
          <a href="#contact">Contact</a>
        </div>
        <div className="pn-fh-nav-actions">
          <button
            className={`pn-fh-theme${themeAnimating ? " pn-fh-theme--animating" : ""}`}
            type="button"
            onClick={onToggleTheme}
            onAnimationEnd={onThemeAnimationEnd}
            aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
          >
            <span aria-hidden="true">{darkMode ? "☀" : "☾"}</span>
          </button>
          <button className="pn-fh-login" type="button" onClick={onLoginClick}>
            {authRole ? "User profile" : "Log in"}
          </button>
        </div>
      </nav>

      <section className="pn-fh-hero" id="home">
        <div className="pn-fh-glow" aria-hidden="true" />

        <p className="pn-fh-kicker">Smart city parking</p>
        <h1>
          Parking that feels
          <br />
          like coming home.
        </h1>
        <p className="pn-fh-copy">
          Reserve a verified space before you leave the house — no circling
          the block, no surprises, no wasted time.
        </p>

        <div className="pn-fh-stage">
          <aside className="pn-fh-float pn-fh-float-left">
            <span className="pn-fh-float-icon">⌖</span>
            <h3>Live availability</h3>
            <p>Open spaces update in real time, so what you see is what you get.</p>
          </aside>

          <div className="pn-fh-illustration" role="img" aria-label="Illustration of a parking lot with a live open space highlighted">
            <svg viewBox="0 0 360 300" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="18" y="24" width="324" height="252" rx="20" fill="#161014" stroke="rgba(255,255,255,0.06)" />
              {[0, 1, 2, 3].map((row) => (
                <g key={row}>
                  <line x1="18" y1={72 + row * 52} x2="342" y2={72 + row * 52} stroke="rgba(255,255,255,0.06)" strokeWidth="2" />
                  {[0, 1, 2, 3, 4].map((col) => (
                    <line
                      key={col}
                      x1={66 + col * 56}
                      y1={24 + row * 52}
                      x2={66 + col * 56}
                      y2={24 + (row + 1) * 52}
                      stroke="rgba(255,255,255,0.05)"
                      strokeWidth="2"
                    />
                  ))}
                </g>
              ))}
              <rect x="122" y="128" width="112" height="92" rx="10" fill="url(#pn-fh-bay)" />
              <g transform="translate(138,150)">
                <rect x="0" y="18" width="80" height="30" rx="9" fill="#f4f4f5" />
                <rect x="10" y="4" width="60" height="22" rx="8" fill="#f4f4f5" />
                <circle cx="16" cy="50" r="8" fill="#161014" />
                <circle cx="64" cy="50" r="8" fill="#161014" />
              </g>
              <defs>
                <linearGradient id="pn-fh-bay" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#e8394c" />
                  <stop offset="1" stopColor="#7c1424" />
                </linearGradient>
              </defs>
            </svg>
            <span className="pn-fh-dot pn-fh-dot-1" />
            <span className="pn-fh-dot pn-fh-dot-2" />
          </div>

          <aside className="pn-fh-float pn-fh-float-right">
            <span className="pn-fh-pill">Parking services</span>
            <ul>
              {SERVICES.map((service) => (
                <li key={service}>{service}</li>
              ))}
            </ul>
          </aside>

          <aside className="pn-fh-float pn-fh-cta">
            <span className="pn-fh-avatar" aria-hidden="true">⌖</span>
            <h3>Secure your spot</h3>
            <p>Reserve now and skip the search when you arrive.</p>
          </aside>
        </div>

        <div className="pn-fh-carousel">
          <button type="button" onClick={showPrevHighlight} aria-label="Previous highlight">
            ‹
          </button>
          <span key={highlightIndex}>{HIGHLIGHTS[highlightIndex]}</span>
          <button type="button" onClick={showNextHighlight} aria-label="Next highlight">
            ›
          </button>
        </div>

        <div className="pn-fh-stats" aria-label="ParkNova at a glance">
          {STATS.map((stat) => (
            <div className="pn-fh-stat" key={stat.label}>
              <span className="pn-fh-stat-icon" aria-hidden="true">{stat.icon}</span>
              <div>
                <strong>{stat.value}</strong>
                <small>{stat.label}</small>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default HomeHero;
